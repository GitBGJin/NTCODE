﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmartEP.DomainModel.WaterQualityControlOperation
{
    /// <summary>
    /// 名称：TaskActionConfigEntity.cs
    /// 创建人：窦曙健
    /// 创建日期：2015-10-13
    /// 维护人员：
    /// 最新维护人员：
    /// 最新维护日期：
    /// 功能摘要：
    /// 任务行动点配置表实体类
    /// 版权所有(C)：江苏远大信息股份有限公司
    public class TaskActionConfigEntity
    {
        #region Model
        private Guid _missionid;
        private Guid _actionid;
        /// <summary>
        /// 
        /// </summary>
        public Guid MissionID
        {
            set { _missionid = value; }
            get { return _missionid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Guid ActionID
        {
            set { _actionid = value; }
            get { return _actionid; }
        }
        #endregion Model
    }
}
