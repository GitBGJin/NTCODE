﻿using log4net;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace highchart_export_module_asp_net
{
    public partial class _Default : System.Web.UI.Page
    {
        ILog log = LogManager.GetLogger("App.Logging");//获取一个日志记录器
        DAL d_DAL = new DAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            //ThreadPool.QueueUserWorkItem(new WaitCallback(this.exporting));
            if (!IsPostBack)
            {
                GetData();
                
            }
        }
        private void GetData()
        {
            try
            {
                //string sTime = "2017-07-01";
                //string eTime = "2017-07-02";
                string sTime = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:00");
                string eTime = DateTime.Now.ToString("yyyy-MM-dd HH:00");

                //log.Info("时间段："+sTime + "-----" + eTime);

                DataTable dt = d_DAL.GetLadarData("extin532", sTime, eTime);
                //DataTable dtex355 = d_DAL.GetLadarData("extin355", sTime, eTime);
                //DataTable dtdepol = d_DAL.GetLadarData("depol", sTime, eTime);
                //DataView dtH = d_DAL.GetHeightData("height", sTime, eTime);

                //if (dtH.ToTable().Rows.Count > 0)
                //{
                //    DataTable dtTime = dtH.ToTable();
                //    dtTime.Columns.Remove("Number");
                //    hdCount.Value = dtTime.Rows.Count.ToString();
                //    DataTable dtBorder = dtH.ToTable();
                //    dtBorder.Columns.Remove("DateTime");
                //    hdTime.Value = ToStringNew(dtTime);
                //    hdBorder.Value = ToString(dtBorder);
                //}
                //else
                //{
                //    hdCount.Value = "1";
                //    hdTime.Value = "[]";
                //    hdBorder.Value = "[]";
                //}

                DataTable dts = new DataTable();
                //DataTable dte = new DataTable();
                //DataTable dtd = new DataTable();

                dts.Columns.Add("xValue", typeof(string));
                dts.Columns.Add("yValue", typeof(string));
                dts.Columns.Add("zValue", typeof(string));

                //dte.Columns.Add("xValue", typeof(string));
                //dte.Columns.Add("yValue", typeof(string));
                //dte.Columns.Add("zValue", typeof(string));

                //dtd.Columns.Add("xValue", typeof(string));
                //dtd.Columns.Add("yValue", typeof(string));
                //dtd.Columns.Add("zValue", typeof(string));

                foreach (DataRow dr in dt.Rows)
                {
                    DataRow drNew = dts.NewRow();
                    drNew["xValue"] = Convert.ToDateTime(dr["DateTime"].ToString()).ToString("MM/dd HH:mm:ss");
                    drNew["yValue"] = dr["Height"].ToString().Substring(0, dr["Height"].ToString().Length - 2);
                    drNew["zValue"] = dr["Number"];
                    dts.Rows.Add(drNew);
                }

                //foreach (DataRow dr in dtex355.Rows)
                //{
                //    DataRow drNewe = dtex355.NewRow();
                //    drNewe["xValue"] = Convert.ToDateTime(dr["DateTime"].ToString()).ToString("MM/dd HH:mm:ss");
                //    drNewe["yValue"] = dr["Height"].ToString().Substring(0, dr["Height"].ToString().Length - 2);
                //    drNewe["zValue"] = dr["Number"];
                //    dte.Rows.Add(drNewe);
                //}

                //foreach (DataRow dr in dtdepol.Rows)
                //{
                //    DataRow drNewd = dtdepol.NewRow();
                //    drNewd["xValue"] = Convert.ToDateTime(dr["DateTime"].ToString()).ToString("MM/dd HH:mm:ss");
                //    drNewd["yValue"] = dr["Height"].ToString().Substring(0, dr["Height"].ToString().Length - 2);
                //    drNewd["zValue"] = dr["Number"];
                //    dtd.Rows.Add(drNewd);
                //}

                HiddenData.Value = JsonHelper.ToJson(dts);
                //HiddenDatae.Value = JsonHelper.ToJson(dte);
                //HiddenDatad.Value = JsonHelper.ToJson(dtd);
            }
            catch (Exception ex)
            {
                log.Error(ex.ToString());
            }
        }
        public static string ToString(DataTable dt)
        {
            StringBuilder jsonString = new StringBuilder();
            jsonString.Append("[");
            DataRowCollection drc = dt.Rows;
            for (int i = 0; i < drc.Count; i++)
            {
                string strValue = drc[i][0].ToString();

                jsonString.Append(strValue + ",");

            }

            if (jsonString.ToString() != "[") jsonString.Remove(jsonString.Length - 1, 1);
            jsonString.Append("]");
            return jsonString.ToString();
        }
        public static string ToStringNew(DataTable dt)
        {
            StringBuilder jsonString = new StringBuilder();
            jsonString.Append("[");
            DataRowCollection drc = dt.Rows;
            for (int i = 0; i < drc.Count; i++)
            {
                string strValue = Convert.ToDateTime(drc[i][0].ToString()).ToString("MM-dd HH:mm:ss");

                jsonString.Append("\"" + strValue + "\",");

            }

            if (jsonString.ToString() != "[") jsonString.Remove(jsonString.Length - 1, 1);
            jsonString.Append("]");
            return jsonString.ToString();
        }
    }
}
